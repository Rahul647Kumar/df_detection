from flask import Flask, render_template, request, jsonify
import os
import torch
import cv2
from torch import nn
from torchvision import models, transforms
import numpy as np
import random

# Flask Setup
app = Flask(__name__)
UPLOAD_FOLDER = 'Uploaded_Files'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Configuration
im_size = 112
mean = [0.485, 0.456, 0.406]
std = [0.229, 0.224, 0.225]

# Define transforms
transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize(mean=mean, std=std)
])

random.seed(42)
np.random.seed(42)
torch.manual_seed(42)
torch.cuda.manual_seed_all(42)

# Model Architecture
class Model(nn.Module):
    def __init__(self, num_classes=2):
        super(Model, self).__init__()
        model = models.resnext50_32x4d(pretrained=True)
        self.feature_extractor = nn.Sequential(*list(model.children())[:-2])  # Remove last layers
        self.avgpool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Linear(2048, num_classes)

    def forward(self, x):
        features = self.feature_extractor(x)
        x = self.avgpool(features)
        x = x.view(x.size(0), -1)  # Flatten the tensor
        x = self.fc(x)
        return x

def apply_confidence_threshold(predictions, confidences, threshold=0.80):
    avg_confidence = np.mean(confidences)
    if avg_confidence >= threshold:
        return max(set(predictions), key=predictions.count)
    else:
        return "UNDETERMINED"  # or "FAKE"

# Extract and preprocess frames
def extract_frames(video_path, num_frames=20):
    cap = cv2.VideoCapture(video_path)
    frames = []
    success = True
    while success and len(frames) < num_frames:
        success, frame = cap.read()
        if success:
            frame = cv2.resize(frame, (im_size, im_size))
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)  # Convert BGR to RGB
            frames.append(transform(frame))
    cap.release()
    if not frames:
        print(f"No frames extracted from {video_path}. Please check the video file.")
        return None
    print(f"Extracted {len(frames)} frames.")
    return torch.stack(frames)

# Predict on frames
def predict_on_frames(model, frames):
    model.eval()
    predictions = []
    confidences = []
    with torch.no_grad():
        for i, frame in enumerate(frames):
            frame = frame.unsqueeze(0)  # Add batch dimension
            logits = model(frame)
            probs = torch.nn.Softmax(dim=1)(logits)
            confidence, prediction = torch.max(probs, 1)
            predictions.append(prediction.item())
            confidences.append(confidence.item())
            print(f"Frame {i+1}: Prediction={prediction.item()}, Confidence={confidence.item() * 100:.2f}%")
    return predictions, confidences

# Detect fake video
def detect_fake_video(video_path):
    frames = extract_frames(video_path)
    if frames is None or len(frames) == 0:
        return None, 0.0

    model = Model()
    model_path = "model/df_model.pt"  # Change this to your model's path

    # Check if model file exists
    if not os.path.exists(model_path):
        print(f"Model file not found: {model_path}")
        return None, 0.0

    try:
        checkpoint = torch.load(model_path, map_location='cpu')
        model.load_state_dict(checkpoint, strict=False)
        print("Model loaded successfully.")
    except Exception as e:
        print(f"Error loading model weights: {e}")
        return None, 0.0

    predictions, confidences = predict_on_frames(model, frames)
    if not predictions:
        return None, 0.0

    # Majority voting for prediction
    final_prediction = max(set(predictions), key=predictions.count)
    avg_confidence = np.mean(confidences) * 100
    return final_prediction, avg_confidence

# Flask Routes
@app.route('/', methods=['GET'])
def homepage():
    return render_template('index.html')

@app.route('/Detect', methods=['POST'])
def detect_page():
    if 'video' not in request.files:
        return jsonify({'output': 'No video file provided.', 'confidence': 0.0})

    video = request.files['video']
    if not video.filename.endswith(('.mp4', '.avi', '.mov', '.mkv')):
        return jsonify({'output': 'Invalid video format. Only MP4, AVI, MOV, MKV are supported.', 'confidence': 0.0})

    video_filename = os.path.join(app.config['UPLOAD_FOLDER'], video.filename)
    video.save(video_filename)

    try:
        prediction, confidence = detect_fake_video(video_filename)
    finally:
        if os.path.exists(video_filename):
            os.remove(video_filename)  # Clean up the uploaded file

    if prediction is None:
        return jsonify({'output': 'Error in frame extraction or model processing. Please check the video or model setup.', 'confidence': 0.0})

    result = "REAL" if prediction == 1 else "FAKE"
    return jsonify({'output': result, 'confidence': confidence})

if __name__ == "__main__":
    if not os.path.exists(app.config['UPLOAD_FOLDER']):
        os.makedirs(app.config['UPLOAD_FOLDER'])
    app.run(port=3000, debug=True)
